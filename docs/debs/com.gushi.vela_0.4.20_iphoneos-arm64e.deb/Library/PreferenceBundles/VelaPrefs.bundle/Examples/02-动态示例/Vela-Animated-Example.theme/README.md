# 原创动态教学主题
用浏览器打开 Preview.html 查看每个状态的图形和摆动示意；这不是 CA 播放器，原生效果请导入 Vela 验证。
这些 main.caml、状态与动画均从零编写，assets/ 是本工具原创 PNG；未复制已有 .ca。
每包只包含 main.caml、index.xml 和 assets/，图层用 64×64 画布，状态只切换各组 opacity，子图层做轻微摆动。
本示例 index.xml 使用 geometryFlipped=true，对齐 PNG/SVG 向下的画布坐标；已有的其他 CA 包应保留作者自己的坐标声明。
修改图形：编辑 Sources/功能键/状态.svg，再导出同尺寸透明 PNG 覆盖对应 assets/ 文件。
修改速度：main.caml 的 duration="2.4" 控制摆动；duration="0.22" 控制状态淡入淡出。
修改幅度：transform.rotation.z 的 values 使用弧度。0.055 约为 3.15°，-0.04 约为 -2.29°；最后回到 0，避免循环跳变。
添加状态：复制一个 state 图层和 LKState，并为每个状态设置各 state 图层的 opacity，最后在 VelaTheme.plist/Icons/功能键/States 对接 Vela 状态。
静音 on→silent；旋转 on→locked；深色 on→dark。亮度 min/mid/full、音量 mute/min/half/full 由滑块数值选择，不用 on/off 代替档位。
本主题没有 Icons/，所以不会被同功能的静态图遮住。不要把预览图放到 Icons/。
