# Vela 原创主题示例：从预览到制作

这里的图标、PNG、SVG 和动画均由 Vela 的示例生成器从简单几何从零绘制、编写，**不使用已有系统或第三方 CA 包，也不复制现有主题的图片**。它们是便于学习的基础图形，不是系统图标的复刻版。

## 先看效果，不必先读代码

1. 打开 **01-静态示例/Vela-Static-Example.theme/Preview.html**：选择开、关或播放状态，查看对应的原创图形。
2. 打开 **02-动态示例/Vela-Animated-Example.theme/Preview.html**：选择每个按钮的状态，预览轻微摆动，也可暂停演示动画。
3. 这些 HTML 可以离线用浏览器打开，不需要账户或网络。浏览器展示的是状态图片和摆动示意，**不是 CA 解码器**；真实配色、原生动画和状态切换请把同目录 ZIP 导入 Vela 验证。
4. 每个主题同时提供展开的文件夹和独立 ZIP。查看源图、修改素材不必先解压 ZIP。不要导入整个示例总目录。

**03-旧格式参考只保留历史路径和命名说明，不再附带旧主题图片、CA 或可安装的旧主题包。**
你自己的旧主题仍然可以使用，兼容加载功能没有移除。

## 主题应该放在哪里

- RootHide：当前越狱根下的 `Library/Themes/Vela/`。
- rootless：`/var/mobile/Library/Theme/Vela/`。
- 设置 → 图标主题 → 主题目录与命名会显示当前手机的实际目录并支持复制。最方便的方法是在图标主题页直接导入单个 ZIP。

只放一个完整的 `你的主题.theme/`，不要再套一层 `System/Library`、`Library/Themes`，也不要写死随机 `.jbroot-*`。Vela 读取主题，不挂载或替换系统文件。

## 一眼看懂文件树

```text
Vela/                               当前手机的主题根目录
└── 我的主题.theme/                   复制这一整个文件夹并改名
    ├── VelaTheme.plist               可选：名称、特殊状态映射
    ├── Preview.html                  浏览器离线教学预览；不参与面板渲染
    ├── README.md                     这个主题的制作说明
    ├── provenance.json               原创声明及运行 PNG 与源图的对应关系
    ├── Sources/                      可编辑 SVG 源图；不参与面板渲染
    │   └── toggle.mute/
    │       ├── off.svg
    │       └── on.svg
    ├── Icons/                        静态主题使用
    │   ├── toggle.mute/
    │   │   ├── on@3x.png             静音已打开
    │   │   └── off@3x.png            响铃／静音关闭
    │   └── media.play/
    │       ├── playing@3x.png        正在播放时显示暂停图
    │       └── paused@3x.png         暂停时显示播放图
    └── Animations/                   动态主题使用：完整 .ca 文件夹
        └── toggle.mute.ca/
            ├── main.caml             从零编写的图层、状态与动画
            ├── index.xml             rootDocument=main.caml
            └── assets/
                ├── ringer.png        原创响铃图
                └── silent.png        原创静音图
```

上面把两种方式放在同一张结构图里便于对照；**实际动态示例不含 Icons/**，避免静态图优先而遮住动画。静态主题不必有 Animations/，动态主题也不必有 Icons/。预览、说明、SVG 源图是制作辅助文件，Vela 只读取指定的运行素材。

## 自己的素材放在哪里

- 一张透明 PNG：`Icons/功能键/default@3x.png`。也支持 `@2x.png` 和不带倍率的 `.png`。
- 两张开关 PNG：`Icons/功能键/on@3x.png`、`off@3x.png`。on 表示该功能已打开，不表示这张图片一定更亮。
- 已有的自己制作的 CA：完整放入 `Animations/功能键.ca/`。保留 `main.caml`、`index.xml` 和引用的全部 `assets/`；不要只复制 CAML 或留下绝对图片路径。
- 原创示例的 SVG：在 `Sources/` 编辑，导出相同尺寸、透明背景的 PNG 后替换对应 `Icons/` 或 `assets/`。修改 SVG 本身不会自动修改已导出的 PNG。
- 同一功能同时有 PNG 和 CA 时，PNG 优先。不要把动画的预览 PNG 放进 Icons/。

未提供素材的功能自动使用系统原生图标，不要拿不相关的图标凑数。完整功能键和状态见同目录 **图标命名.csv**。

## 动态示例怎么工作

七个独立示例分别覆盖：静音、旋转锁定、深浅色、亮度、音量、勿扰、游戏专注。

原创示例的 index.xml 使用 geometryFlipped=true，对齐 PNG/SVG 向下的画布坐标，避免上下翻转；别的已有 CA 包应保留作者自己的坐标声明。

每包使用 64×64 画布，一种状态一组图层；LKState 只调整各状态组的 opacity。每个状态组的子图层做幅度很小的摆动，切换状态时用 0.22 秒淡入淡出。没有系统资源路径、系统 CA 引用或对其他主题的依赖。

可直接从这三个地方开始改：

- **换图**：替换 `assets/状态名.png`，PNG 保持透明背景，建议 192×192。
- **改速度**：`main.caml` 里 `duration="2.4"` 是摆动周期；`duration="0.22"` 是状态过渡时长。
- **改幅度**：`transform.rotation.z` 的值是弧度。`0.055` 约 3.15°，`-0.04` 约 -2.29°；首尾都回到 0，避免循环突然跳变。

需要重建整套教学示例时，在源码根目录运行 `python tools/build_theme_example.py`，需要 Pillow。工具只读取源码里的几何定义和说明，不读取微信归档、系统素材或转换后的主题。普通主题作者直接修改示例文件即可，不需要运行生成器。

## 状态怎么命名

- `toggle.mute`：off → ringer，on → silent。
- `toggle.rotation`：off → unlocked，on → locked。
- `toggle.appearance`：off → light（太阳），on → dark（月亮）。
- `toggle.focus`、`focus.gaming`：off → OFF，on → ON。
- `slider.brightness`：按滑块数值使用 min / mid / full。
- `slider.volume`：按滑块数值使用 mute / min / half / full。
- `media.play`（静态示例）：paused 显示播放图，playing 显示暂停图。

亮度、音量会按当前数值选档，不能用单纯 on/off 代替档位。一级、二级、三级页面共用 `slider.brightness` 和 `slider.volume`。

`VelaTheme.plist` 中的 `Icons → 功能键 → States` 把 Vela 状态映射到 LKState 名称；名称区分大小写。例如：

```xml
<key>toggle.mute</key><dict>
  <key>Package</key><string>Animations/toggle.mute.ca</string>
  <key>States</key><dict>
    <key>off</key><string>ringer</string>
    <key>on</key><string>silent</string>
  </dict>
</dict>
```

专注子模式各用各的功能键：`focus.gaming`、`focus.sleep`、`focus.driving`、`focus.fitness`、`focus.personal`、`focus.work`、`focus.mindfulness`、`focus.reading`。勿扰用 `toggle.focus`。本次游戏示例使用原创手柄图案。

音乐识别用 `com.apple.shazamkit.controlcenter.ShazamModule`；播报通知用 `com.apple.siri.SpokenNotificationsModule`。自定义专注符号无法识别时保留原生。

## 更新时怎样保留自己的修改

设置里的“打开标准示例文件夹”打开专用 `.Examples/`。它不会自动启用示例主题；更新示例时会替换这个专用目录。

**先复制整个 .theme 并改名，放到主题根目录，再开始制作。** 不要把唯一一份自制作品长期留在 `.Examples/`。导入同名主题会提示重名，不会直接覆盖已有用户主题。
