# 旧格式只保留命名参考
这里不再附带旧主题图片或 CA。制作新包请从 01/02 的原创教学主题开始。
旧静态路径：主题.theme/Folders/Prysm/Icons/wifi@3x.png
原生/第三方模块路径：主题.theme/Bundles/真实模块标识/原资源名.png
ringer 的 on=响铃、off=静音；转换成 toggle.mute 的 on/off 时要反转。
兼容层仍能读取你自己已有的旧主题；不需要挂载系统文件，不依赖旧 FlipConvert 运行时。
