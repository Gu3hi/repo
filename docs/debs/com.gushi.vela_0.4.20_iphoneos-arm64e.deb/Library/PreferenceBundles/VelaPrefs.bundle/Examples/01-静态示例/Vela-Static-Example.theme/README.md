# 原创静态教学主题
先用浏览器打开 Preview.html 选择状态；普通文件夹可直接看 PNG，无需解压。
Icons/功能键/状态@3x.png 是运行素材，Sources/ 中的 SVG 是可编辑源图。SVG 不参与 Vela 加载。
所有图形从简单几何绘制，不来自系统或第三方主题。静音 on=静音、off=响铃；深色 on=月亮、off=太阳；media.play 的 playing=暂停图、paused=播放图。
这是结构教学主题，未画出的功能沿用系统图标。先复制并改名，避免更新覆盖你的作品。
